// const userSettings = {
//   delay: 300,
//   wait: 1500,
//   stand: 1500,
//   // alternativeCode:'<span>狼は走れ、</span><span>豚は転がれ</span>',
// };
