const userSettings = {
  delay: 300,
  wait: 1500,
  alternativeCode:'狼は走れ、豚は転がれ',
};
